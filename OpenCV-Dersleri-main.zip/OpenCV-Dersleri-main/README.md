Burada yolov4.weights dosyasını yüksek boyuttan dolayı yükleyemedim. Ama internetten aratarak bulabilirsiniz.
